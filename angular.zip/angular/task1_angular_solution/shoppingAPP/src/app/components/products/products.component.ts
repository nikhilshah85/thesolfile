import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-products',
  templateUrl: './products.component.html',
  styleUrls: ['./products.component.css']
})
export class ProductsComponent implements OnInit {


  productList:any = [];
getAllProducts()
{
  
   this.productList = [ 
    {pId:101, pName: 'Pepsi', pCategory: 'Cold-Drink', pPrice:50, pIsInStock:true},
    {pId:102, pName: 'Samsung Galaxy', pCategory: 'Electronics', pPrice:40000, pIsInStock:true},
    {pId:103, pName: 'Hush Puppies', pCategory: 'Accessories', pPrice:3800, pIsInStock:false},
    {pId:104, pName: 'Red-Tape', pCategory: 'Accessories', pPrice:5200, pIsInStock:true},
    {pId:105, pName: 'Nike', pCategory: 'Accessories', pPrice:6400, pIsInStock:true},
    {pId:106, pName: 'Coke', pCategory: 'Cold-Drink', pPrice:60, pIsInStock:true},
    {pId:107, pName: 'CK', pCategory: 'Accessories', pPrice:2100, pIsInStock:false},
    {pId:108, pName: 'IPhone', pCategory: 'Electronics', pPrice:140000, pIsInStock:true},
    {pId:109, pName: ' Boat', pCategory: 'Electronics', pPrice:1800, pIsInStock:true},
    {pId:110, pName: ' Air Pods', pCategory: 'Electronics', pPrice:27000, pIsInStock:false},
]
    return this.productList;
}

  constructor() { }

  ngOnInit(): void {
  }

}
